# Security notes for SARAB AI STUDIO 7.0 maintenance build

## Before public deployment

1. Set `SARAB_API_TOKEN` to a long random secret in the hosting provider's environment settings. Never commit it or put it in this ZIP.
2. Use the HTTPS URL provided by Render. The built-in Python server does not terminate TLS itself.
3. Treat this as a single-owner service. It has no user accounts or per-user media isolation; do not share the bearer token.
4. Configure persistent storage if uploaded media and job history must survive Render restarts/redeploys. The default Render filesystem may be ephemeral.
5. The default maximum request body is 60 MiB (`SARAB_MAX_UPLOAD_BYTES`). Adjust only after considering memory and hosting limits.
6. Upload only media you own or are licensed to use.

## Implemented controls

- Optional bearer-token authentication for API endpoints and generated video downloads.
- Constant-time token comparison.
- Per-process request rate limiting (60 requests/minute/IP).
- Request-body size limit.
- Extension allowlists for images, audio, and SRT subtitle uploads; Pillow verifies image decoding.
- Sanitized upload/output filenames and fixed media directories.
- Generated-output-only file serving.
- Correct 404 for unknown job IDs.
- Security headers including `X-Content-Type-Options: nosniff`, frame denial, and same-origin referrer policy.

## Remaining limitations

- Rate limiting is in-memory and resets on restart; it is not a distributed WAF.
- This is not a multi-tenant SaaS. Do not give the API token to other users.
- No malware scanning is included. Keep Python, Pillow, and FFmpeg updated.
- Job execution/state is local to one process and filesystem; no distributed queue is included.
- Social OAuth/publishing and native APK packaging are not implemented.
