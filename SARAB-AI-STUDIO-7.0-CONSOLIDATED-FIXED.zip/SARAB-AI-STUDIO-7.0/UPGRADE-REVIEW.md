# SARAB AI STUDIO 7.0 – consolidated source review

## Source baseline

The uploaded `SARAB-AI-STUDIO-7.0-FINAL-20261110.zip` was used as the working source. The uploaded `sarab-ai-studio-main.zip`, `sarab-ai-studio-maintenance-build.zip`, `sarab-ai-studio-v7-zero-cost.zip`, and the separate `UPGRADE-REVIEW.md` were inspected for context and defects. The `SARAB-AI-STUDIO-7.0-CONSOLIDATED.zip` upload failed ZIP central-directory validation and was not used as a source archive.

## Changes applied in this consolidation

1. Replaced the incomplete backend API server with a unified API for status, media/music/subtitle listing, multipart uploads, render creation, job polling, and local planner/SEO-template endpoints.
2. Fixed the missing filename helper and corrected unit tests that previously could not import it.
3. Added `ThreadingHTTPServer`, platform `PORT` support, optional bearer-token auth, request size limits, per-IP in-memory rate limiting, safe filenames, and restricted media output paths.
4. Connected the browser upload flow and local music/subtitle selectors to the server endpoints.
5. Rebuilt the FFmpeg slideshow path so silent and music/subtitle renders reach the requested duration in both vertical and landscape output.
6. Fixed blank music/subtitle selections so they remain optional.
7. Removed the global `pkill -f python` command from `start.sh`.
8. Rewrote build, security, installation, and deployment documentation to distinguish verified features from unavailable features.

## Known limitations

- AI planner and SEO metadata are deterministic templates, not a generative AI model.
- No reliable AI image/voice generation service is integrated.
- Social publishing/OAuth is not implemented.
- No native APK build pipeline; the supplied app is a web/PWA interface.
- The renderer is 720p/12fps photo slideshow output, not a multi-track professional NLE or 1080p/4K mastering pipeline.
- Single-owner only; no per-user storage isolation or accounts.
- Rate limiting is in-memory and the job queue is local to one process.
- Persistent Render storage must be configured separately.
- Android/Termux installation and live Render deployment were not performed in this workspace.

See `FINAL-TEST-REPORT.md`, `SECURITY.md`, `README.md`, and `DEPLOY-RENDER.txt` before deployment.
