"""SARAB AI STUDIO HTTP API. Uses stdlib only; configure SARAB_API_TOKEN for public hosting."""
import os, sys, json, time, uuid, re, threading, secrets, mimetypes
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, unquote
from email.parser import BytesParser
from email.policy import default

ROOT = Path(os.environ.get('SARAB_ROOT', Path(__file__).resolve().parents[2])).resolve()
sys.path.insert(0, str(ROOT))
WEB = ROOT / 'web'
MEDIA = ROOT / 'media'
INPUT, MUSIC, SUBS, OUTPUT, TEMP = [MEDIA / x for x in ('input','music','subtitles','output','temp')]
LOGS = ROOT / 'logs'
for d in (INPUT, MUSIC, SUBS, OUTPUT, TEMP, LOGS): d.mkdir(parents=True, exist_ok=True)
JOBS_DIR = LOGS / 'jobs'; JOBS_DIR.mkdir(exist_ok=True)
TOKEN = os.environ.get('SARAB_API_TOKEN', '').strip()
MAX_UPLOAD = int(os.environ.get('SARAB_MAX_UPLOAD_BYTES', '62914560'))
MAX_CONCURRENT = max(1, int(os.environ.get('SARAB_MAX_CONCURRENT_RENDERS', '1')))
RENDER_SEM = threading.BoundedSemaphore(MAX_CONCURRENT)
LOCK = threading.RLock(); RATE = {}
IMAGE_EXTS={'.jpg','.jpeg','.png','.webp'}; AUDIO_EXTS={'.mp3','.wav','.m4a','.aac','.ogg','.flac'}

from backend.video_engine.editor import render_slideshow
from backend.video_engine.engine import get_status, list_media
from backend.ai_engine.planner import create_video_plan
from backend.ai_engine.metadata import generate_seo_metadata


def safe_filename(value, fallback='upload'):
    value = unquote(str(value or '')).replace('\\','/').split('/')[-1]
    value = re.sub(r'[^A-Za-z0-9._-]+', '_', value).strip('._')
    return (value[:100] or fallback)

def read_job(jid):
    p=JOBS_DIR/(safe_filename(jid)+'.json')
    try: return json.loads(p.read_text('utf-8'))
    except (OSError, ValueError): return None

def write_job(jid, data):
    p=JOBS_DIR/(safe_filename(jid)+'.json'); tmp=p.with_suffix('.tmp')
    with LOCK: tmp.write_text(json.dumps(data, ensure_ascii=False), 'utf-8'); tmp.replace(p)

def list_files(folder, exts):
    return [{'name':p.name,'size_bytes':p.stat().st_size} for p in sorted(folder.iterdir()) if p.is_file() and p.suffix.lower() in exts]

class Handler(BaseHTTPRequestHandler):
    server_version='SARABStudio/7.0'
    def log_message(self, fmt, *args):
        if os.environ.get('SARAB_ACCESS_LOG','1') == '1': super().log_message(fmt,*args)
    def _headers(self, ct='application/json; charset=utf-8', length=None):
        self.send_header('Content-Type',ct)
        if length is not None: self.send_header('Content-Length',str(length))
        self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','same-origin'); self.send_header('X-Frame-Options','DENY'); self.send_header('Cache-Control','no-store')
        origin=self.headers.get('Origin'); allowed={x.strip() for x in os.environ.get('SARAB_ALLOWED_ORIGINS','').split(',') if x.strip()}
        if origin and (origin==f'{self.headers.get("X-Forwarded-Proto","http")}://{self.headers.get("Host","")}' or origin in allowed):
            self.send_header('Access-Control-Allow-Origin',origin); self.send_header('Vary','Origin')
        self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type'); self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
    def _send(self, data, code=200, ct='application/json; charset=utf-8'):
        raw=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False).encode()
        self.send_response(code); self._headers(ct,len(raw)); self.end_headers(); self.wfile.write(raw)
    def _auth(self):
        if not TOKEN: return True
        supplied=self.headers.get('Authorization','')
        return secrets.compare_digest(supplied, 'Bearer '+TOKEN)
    def _rate(self):
        ip=self.client_address[0]; now=time.time()
        with LOCK:
            arr=[t for t in RATE.get(ip,[]) if now-t<60]
            if len(arr)>=60: RATE[ip]=arr; return False
            arr.append(now); RATE[ip]=arr; return True
    def _body(self):
        n=int(self.headers.get('Content-Length','0'))
        if n<0 or n>MAX_UPLOAD: raise ValueError('Request exceeds configured size limit.')
        return self.rfile.read(n)
    def do_OPTIONS(self): self._send({},204)
    def do_GET(self):
        if not self._auth(): return self._send({'error':'Unauthorized'},401)
        if not self._rate(): return self._send({'error':'Rate limit exceeded'},429)
        p=urlparse(self.path).path
        if p=='/api/v1/status':
            st=get_status(); return self._send({'status':'ready' if st['status']=='ready' else 'degraded','version':'7.0-maintenance','video_engine':st,'limits':{'max_duration_seconds':600,'max_upload_bytes':MAX_UPLOAD}})
        if p=='/api/v1/media': return self._send({'items':list_media()})
        if p=='/api/v1/music': return self._send({'items':list_files(MUSIC,AUDIO_EXTS)})
        if p=='/api/v1/subtitles': return self._send({'items':list_files(SUBS,{'.srt'})})
        if p.startswith('/api/v1/video/jobs/'):
            jid=p.rsplit('/',1)[-1]; job=read_job(jid)
            return self._send(job or {'error':'Job not found'},200 if job else 404)
        if p in ('/','/index.html'): target=WEB/'index.html'; ct='text/html; charset=utf-8'
        elif p in ('/manifest.json','/sw.js'): target=WEB/p.lstrip('/'); ct='application/manifest+json' if p.endswith('json') else 'application/javascript'
        elif p=='/logo.png': target=ROOT/'logo.png'; ct='image/png'
        elif p.startswith('/media/output/'):
            name=safe_filename(p.split('/')[-1]); target=OUTPUT/name; ct='video/mp4'
        else: return self._send({'error':'Not found'},404)
        if not target.is_file(): return self._send({'error':'Not found'},404)
        try: raw=target.read_bytes()
        except OSError: return self._send({'error':'Unable to read file'},500)
        return self._send(raw,200,ct)
    def do_POST(self):
        if not self._auth(): return self._send({'error':'Unauthorized'},401)
        if not self._rate(): return self._send({'error':'Rate limit exceeded'},429)
        p=urlparse(self.path).path
        try: raw=self._body()
        except (ValueError,OverflowError) as e: return self._send({'error':str(e)},413)
        if p=='/api/v1/media/upload': return self.upload(raw)
        if p=='/api/v1/video/edit': return self.create_render(raw)
        if p=='/api/v1/ai/plan':
            try: b=json.loads(raw or b'{}'); plan=create_video_plan(str(b.get('prompt','')),str(b.get('platform','instagram')),int(b.get('duration',30))); return self._send(plan)
            except Exception as e: return self._send({'error':str(e)},400)
        if p=='/api/v1/ai/metadata':
            try: b=json.loads(raw or b'{}'); return self._send(generate_seo_metadata(str(b.get('topic','School Special'))))
            except Exception as e: return self._send({'error':str(e)},400)
        return self._send({'error':'Endpoint not found'},404)
    def upload(self, raw):
        ctype=self.headers.get('Content-Type','')
        if 'multipart/form-data' not in ctype: return self._send({'error':'Use multipart/form-data.'},400)
        try: msg=BytesParser(policy=default).parsebytes(('Content-Type: '+ctype+'\r\nMIME-Version: 1.0\r\n\r\n').encode()+raw)
        except Exception: return self._send({'error':'Invalid multipart upload.'},400)
        saved=[]
        for part in msg.iter_parts():
            if part.get_content_disposition()!='form-data' or part.get_param('name',header='content-disposition')!='files': continue
            filename=safe_filename(part.get_filename(),'upload'); ext=Path(filename).suffix.lower(); data=part.get_payload(decode=True) or b''
            if not data: continue
            if ext in IMAGE_EXTS: folder=INPUT
            elif ext in AUDIO_EXTS: folder=MUSIC
            elif ext=='.srt': folder=SUBS
            else: return self._send({'error':f'Unsupported file type: {ext or "unknown"}'},415)
            if ext in IMAGE_EXTS:
                try:
                    from PIL import Image
                    import io
                    im=Image.open(io.BytesIO(data)); im.verify()
                except Exception: return self._send({'error':f'{filename} is not a valid image.'},400)
            if ext in AUDIO_EXTS and len(data)>MAX_UPLOAD: return self._send({'error':'Audio file too large.'},413)
            dest=folder/filename
            if dest.exists(): dest=folder/(dest.stem+'_'+uuid.uuid4().hex[:6]+dest.suffix)
            dest.write_bytes(data); saved.append({'name':dest.name,'type':ext[1:]})
        if not saved: return self._send({'error':'No supported files found in upload.'},400)
        return self._send({'uploaded':saved},201)
    def create_render(self, raw):
        try: b=json.loads(raw or b'{}')
        except ValueError: return self._send({'error':'Invalid JSON.'},400)
        try: duration=int(float(b.get('duration',30)))
        except (ValueError,TypeError): return self._send({'error':'Duration must be a number from 5 to 600 seconds.'},400)
        if not 5<=duration<=600: return self._send({'error':'Duration must be between 5 and 600 seconds.'},400)
        photos=[p for p in INPUT.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
        if not photos: return self._send({'error':'Upload at least one photo first.'},400)
        jid='job_'+uuid.uuid4().hex[:12]; name=safe_filename(b.get('out_name','SARAB_VIDEO.mp4'),'SARAB_VIDEO')
        if not name.lower().endswith('.mp4'): name += '.mp4'
        fmt=str(b.get('format','9:16')); raw_music=str(b.get('music_name','') or '').strip(); raw_sub=str(b.get('subtitle_name','') or '').strip()
        music_name=safe_filename(raw_music) if raw_music else ''; sub_name=safe_filename(raw_sub) if raw_sub else ''
        music=(MUSIC/music_name) if music_name else None; subtitle=(SUBS/sub_name) if sub_name else None
        if music and (not music.is_file() or music.suffix.lower() not in AUDIO_EXTS): return self._send({'error':'Selected music file was not found.'},400)
        if subtitle and (not subtitle.is_file() or subtitle.suffix.lower()!='.srt'): return self._send({'error':'Selected subtitle file was not found.'},400)
        state={'job_id':jid,'state':'queued','progress':0,'file_name':name,'created_at':time.time()}; write_job(jid,state)
        def run():
            if not RENDER_SEM.acquire(blocking=False):
                state.update(state='failed',error='Render capacity is busy. Try again shortly.'); write_job(jid,state); return
            try:
                state.update(state='running',progress=5); write_job(jid,state)
                out=OUTPUT/name
                render_slideshow(photos,duration,fmt,out,music,subtitle,lambda n:(state.update(progress=n),write_job(jid,state)))
                state.update(state='completed',progress=100,output='/media/output/'+name); write_job(jid,state)
            except Exception as e:
                state.update(state='failed',error=str(e)[:2000]); write_job(jid,state)
            finally: RENDER_SEM.release()
        threading.Thread(target=run,daemon=True).start()
        return self._send({'job_id':jid,'status':'queued'},202)

if __name__=='__main__':
    port=int(os.environ.get('PORT','7860'))
    print(f'SARAB AI STUDIO listening on 0.0.0.0:{port}')
    ThreadingHTTPServer(('0.0.0.0',port),Handler).serve_forever()
