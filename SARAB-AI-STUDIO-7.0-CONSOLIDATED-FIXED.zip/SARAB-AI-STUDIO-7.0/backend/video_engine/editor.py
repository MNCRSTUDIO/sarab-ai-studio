"""Low-resource FFmpeg photo slideshow renderer used by SARAB AI STUDIO."""
import os, subprocess
from pathlib import Path

IMAGE_EXTS={'.jpg','.jpeg','.png','.webp'}
AUDIO_EXTS={'.mp3','.wav','.m4a','.aac','.ogg','.flac'}

def render_slideshow(images,duration,aspect,output_path,music_path=None,subtitle_path=None,progress=None):
    images=[Path(p).resolve() for p in images if Path(p).is_file() and Path(p).suffix.lower() in IMAGE_EXTS]
    if not images: raise ValueError('Upload at least one valid photo before rendering.')
    duration=int(duration)
    if not 5<=duration<=600: raise ValueError('Duration must be between 5 and 600 seconds.')
    w,h=(1280,720) if aspect in ('16:9','Landscape 16:9 (YouTube)','landscape') else (720,1280)
    out=Path(output_path).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    temp=out.parent.parent/'temp'/f'render_{out.stem}'; temp.mkdir(parents=True,exist_ok=True)
    seg=duration/len(images); clips=[]
    for i,img in enumerate(images):
        clip=temp/f'clip_{i:03d}.mp4'
        vf=f'scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps=12,format=yuv420p'
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate','12','-t',f'{seg:.6f}','-i',str(img),'-vf',vf,'-an','-c:v','libx264','-preset','ultrafast','-crf','28','-pix_fmt','yuv420p',str(clip)]
        res=subprocess.run(cmd,capture_output=True,text=True,timeout=max(60,seg*8+30))
        if res.returncode or not clip.is_file() or clip.stat().st_size<512:
            raise RuntimeError('Unable to prepare slideshow image: '+(res.stderr[-1000:] if res.stderr else img.name))
        clips.append(clip)
        if progress: progress(min(20,5+int(15*(i+1)/len(images))))
    concat=temp/'clips.txt'
    with concat.open('w',encoding='utf-8') as f:
        for clip in clips: f.write("file '"+str(clip).replace("'","'\\''")+"'\n")
    has_audio=bool(music_path and Path(music_path).is_file() and Path(music_path).suffix.lower() in AUDIO_EXTS)
    has_subs=bool(subtitle_path and Path(subtitle_path).is_file() and Path(subtitle_path).suffix.lower()=='.srt')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat)]
    if has_audio: cmd += ['-stream_loop','-1','-i',str(Path(music_path).resolve())]
    if has_subs: cmd += ['-i',str(Path(subtitle_path).resolve())]
    cmd += ['-map','0:v:0','-c:v','copy','-t',str(duration),'-movflags','+faststart']
    if has_audio: cmd += ['-map','1:a:0','-c:a','aac','-b:a','128k']
    if has_subs: cmd += ['-map',f'{2 if has_audio else 1}:0','-c:s','mov_text']
    cmd += [str(out)]
    if progress: progress(35)
    res=subprocess.run(cmd,capture_output=True,text=True,timeout=duration*8+120)
    if res.returncode or not out.is_file() or out.stat().st_size<1024:
        raise RuntimeError('FFmpeg render failed: '+(res.stderr[-1800:] if res.stderr else 'No output produced'))
    if progress: progress(100)
    return str(out)

class VideoEditorEngine:
    def __init__(self,root_dir): self.root=Path(root_dir).resolve()
    def compile(self,scenes,duration,fmt,audio_path,output_path,job_id):
        return render_slideshow(scenes,duration,fmt,output_path,audio_path)
