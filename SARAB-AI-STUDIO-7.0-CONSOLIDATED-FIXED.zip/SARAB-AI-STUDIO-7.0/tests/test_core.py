import os, tempfile, unittest
from backend.api.server import safe_filename, read_job, write_job
from backend.ai_engine.planner import create_video_plan
from backend.ai_engine.metadata import generate_seo_metadata

class CoreTests(unittest.TestCase):
    def test_safe_filename_removes_path_and_traversal(self):
        self.assertEqual(safe_filename('../../hello world.jpg'), 'hello_world.jpg')
        self.assertNotIn('/', safe_filename('..\\..\\secret.txt'))
    def test_safe_filename_empty_fallback(self):
        self.assertEqual(safe_filename('...'), 'upload')
    def test_planner_requires_prompt(self):
        with self.assertRaises(ValueError): create_video_plan('')
    def test_planner_is_explicitly_rule_based(self):
        plan=create_video_plan('School admission promotion','instagram',20)
        self.assertEqual(plan['generated_by'],'local rule-based planner (not generative AI)')
        self.assertEqual(plan['format'],'9:16 vertical')
    def test_planner_rejects_out_of_range_duration(self):
        with self.assertRaises(ValueError): create_video_plan('School', 'instagram', 601)
    def test_metadata_has_required_fields(self):
        result=generate_seo_metadata('School annual day')
        self.assertTrue(result['title']); self.assertTrue(result['description']); self.assertTrue(result['hashtags'])

if __name__=='__main__': unittest.main()
